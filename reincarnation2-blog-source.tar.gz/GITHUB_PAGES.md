# GitHub Pages 发布说明

这个仓库通过 GitHub Actions 自动发布 `dist/public` 中的静态前端。推送到 `main` 后，工作流会构建 Vite 应用、生成 SPA 回退页并部署到 GitHub Pages。

GitHub Pages 适合展示博客的公开页面、文章内容、素材和改进记录。当前项目原本包含服务器端认证、数据库和管理员数据持久化能力，这些能力不能由 GitHub Pages 静态托管单独提供；要使用完整后台，应继续使用全栈部署地址，并把 Pages 作为公开展示入口。

如果需要绑定自定义域名，可以在仓库 Settings → Pages → Custom domain 中配置。仓库 Pages 设置需要选择 GitHub Actions 作为构建与部署来源。


