import { ENV } from "./_core/env";

type SupabaseConfig = {
  url: string;
  serviceRoleKey: string;
};

function getConfig(): SupabaseConfig | null {
  const url = process.env.SUPABASE_URL?.replace(/\/$/, "");
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !serviceRoleKey) return null;
  return { url, serviceRoleKey };
}

export function isSupabaseConfigured() {
  return Boolean(getConfig());
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const config = getConfig();
  if (!config) throw new Error("Supabase is not configured. Add SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY.");
  const headers = new Headers(init.headers);
  headers.set("apikey", config.serviceRoleKey);
  headers.set("Authorization", `Bearer ${config.serviceRoleKey}`);
  headers.set("Content-Type", "application/json");
  const response = await fetch(`${config.url}/rest/v1/${path}`, { ...init, headers });
  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`Supabase request failed (${response.status}): ${detail.slice(0, 500)}`);
  }
  if (response.status === 204) return undefined as T;
  return response.json() as Promise<T>;
}

export type SupabasePost = {
  id: number;
  author_id: string | null;
  category_id: number | null;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  cover_url: string | null;
  status: "draft" | "published" | "archived";
  featured: boolean;
  read_time_minutes: number;
  published_at: string | null;
  created_at: string;
  updated_at: string;
};

export async function listPublishedPosts() {
  return request<SupabasePost[]>("posts?select=*&status=eq.published&order=published_at.desc");
}

export async function listAllPosts() {
  return request<SupabasePost[]>("posts?select=*&order=created_at.desc");
}

export async function getPostBySlug(slug: string) {
  const rows = await request<SupabasePost[]>(`posts?select=*&slug=eq.${encodeURIComponent(slug)}&limit=1`);
  return rows[0] ?? null;
}

export async function createPost(input: Omit<SupabasePost, "id" | "created_at" | "updated_at">) {
  const rows = await request<SupabasePost[]>("posts", { method: "POST", headers: { Prefer: "return=representation" }, body: JSON.stringify(input) });
  return rows[0];
}

export async function updatePost(id: number, input: Partial<Omit<SupabasePost, "id" | "created_at" | "updated_at">>) {
  const rows = await request<SupabasePost[]>(`posts?id=eq.${id}`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify(input) });
  return rows[0] ?? null;
}

export async function deletePost(id: number) {
  await request<void>(`posts?id=eq.${id}`, { method: "DELETE" });
  return { success: true } as const;
}

export function supabaseStatus() {
  return {
    configured: isSupabaseConfigured(),
    projectUrl: process.env.SUPABASE_URL ?? null,
    hasAnonKey: Boolean(process.env.SUPABASE_ANON_KEY),
    hasServiceRoleKey: Boolean(process.env.SUPABASE_SERVICE_ROLE_KEY),
    database: "Supabase Postgres + REST" as const,
  };
}

void ENV;
