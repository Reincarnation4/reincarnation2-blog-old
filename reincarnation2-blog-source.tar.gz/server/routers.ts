import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import {
  createPost,
  deletePost,
  getPostBySlug,
  isSupabaseConfigured,
  listAllPosts,
  listPublishedPosts,
  supabaseStatus,
  updatePost,
} from "./supabase";

const postInput = z.object({
  title: z.string().min(1).max(180),
  slug: z.string().min(1).max(180).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
  excerpt: z.string().max(500).default(""),
  content: z.string().min(1),
  categoryId: z.number().int().positive().nullable().optional(),
  coverUrl: z.string().url().nullable().optional(),
  status: z.enum(["draft", "published", "archived"]).default("draft"),
  featured: z.boolean().default(false),
  readTimeMinutes: z.number().int().min(1).max(180).default(5),
  publishedAt: z.string().datetime().nullable().optional(),
});

function toDbPost(input: z.infer<typeof postInput>) {
  return {
    author_id: null,
    category_id: input.categoryId ?? null,
    title: input.title,
    slug: input.slug,
    excerpt: input.excerpt,
    content: input.content,
    cover_url: input.coverUrl ?? null,
    status: input.status,
    featured: input.featured,
    read_time_minutes: input.readTimeMinutes,
    published_at: input.publishedAt ?? (input.status === "published" ? new Date().toISOString() : null),
  };
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  supabase: router({
    status: publicProcedure.query(() => supabaseStatus()),
  }),

  posts: router({
    list: publicProcedure.query(async () => {
      if (!isSupabaseConfigured()) return { connected: false as const, posts: [] };
      return { connected: true as const, posts: await listPublishedPosts() };
    }),
    bySlug: publicProcedure.input(z.object({ slug: z.string().min(1) })).query(async ({ input }) => {
      if (!isSupabaseConfigured()) return { connected: false as const, post: null };
      return { connected: true as const, post: await getPostBySlug(input.slug) };
    }),
    adminList: adminProcedure.query(async () => {
      if (!isSupabaseConfigured()) return { connected: false as const, posts: [] };
      return { connected: true as const, posts: await listAllPosts() };
    }),
    create: adminProcedure.input(postInput).mutation(async ({ ctx, input }) => {
      if (!isSupabaseConfigured()) throw new Error("Supabase 尚未配置，请先填写服务器环境变量。");
      const post = await createPost(toDbPost(input) as never);
      return { post };
    }),
    update: adminProcedure.input(z.object({ id: z.number().int().positive(), data: postInput.partial() })).mutation(async ({ input }) => {
      if (!isSupabaseConfigured()) throw new Error("Supabase 尚未配置，请先填写服务器环境变量。");
      const post = await updatePost(input.id, toDbPost(input.data as z.infer<typeof postInput>) as never);
      return { post };
    }),
    delete: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => {
      if (!isSupabaseConfigured()) throw new Error("Supabase 尚未配置，请先填写服务器环境变量。");
      return deletePost(input.id);
    }),
  }),
});

export type AppRouter = typeof appRouter;
