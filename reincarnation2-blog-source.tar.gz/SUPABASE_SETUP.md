# Supabase 接入准备清单

## 现在已经写好的部分

项目已经准备好 Supabase 的数据模型和服务端访问层，覆盖用户资料、管理员角色、文章、分类、评论、留言、媒体文件和博客图片存储。文章接口包含公开已发布文章列表、后台文章列表、按 slug 查询、创建、修改和删除；当 Supabase 未配置时，现有博客仍会继续使用本地演示数据，不会因为缺少密钥而打不开。

相关文件：

- `supabase/schema.sql`：在 Supabase SQL Editor 一次性执行的建表、RLS 权限、Storage bucket 和管理员函数。
- `server/supabase.ts`：服务端 Supabase REST 数据访问层，service role key 只在服务器使用。
- `.env.example`：需要部署时填写的环境变量模板。

## 你需要提供什么

你不需要提供密码，也不要把 service role key 直接发在聊天里。完成 Supabase 注册并创建项目后，需要准备以下三项：

| 配置 | 用途 | 是否可发给我 |
| --- | --- | --- |
| Project URL | 识别 Supabase 项目，例如 `https://xxxx.supabase.co` | 可以提供 |
| anon public key | 浏览器端公开 API key | 可以提供，但推荐通过安全配置填写 |
| service_role key | 服务端管理数据库和后台 CRUD | 不要发在聊天中；应填到部署平台的服务器环境变量 |

如果暂时不想处理密钥，你也可以只提供 Project URL 和 anon key，我会继续把前端认证页面和公开读取接好；真正的管理员写入接口仍需要 service role key 配到服务器环境里。

## 手机操作步骤

1. 用手机打开 [Supabase](https://supabase.com/) 并注册。
2. 创建一个新的 Free 项目，项目名称可以填写 `reincarnation2-blog`。
3. 打开项目左侧的 **SQL Editor**，新建 Query。
4. 把项目里的 `supabase/schema.sql` 全部复制进去并点击 Run。
5. 打开 **Project Settings → API**，找到 Project URL、anon public key 和 service_role key。
6. 在 **Authentication → Providers** 中启用 Email provider；建议先关闭“必须邮箱确认”，等登录流程测试成功后再开启。
7. 注册你的管理员账号，邮箱使用 `reincarnation2@qq.com`。
8. 在 SQL Editor 执行：

```sql
update public.profiles
set role = 'admin'
where email = 'reincarnation2@qq.com';
```

## 安全规则

`service_role` key 可以绕过 RLS，权限非常高。它不能放进 `client/`、不能写成 `VITE_SUPABASE_SERVICE_ROLE_KEY`、不能上传到 GitHub，也不要粘贴到聊天里。GitHub Pages 只能承载公开静态文件，不能安全保存这个密钥；接入真实数据库时需要把完整博客部署到支持服务器环境变量的全栈平台。

## 接入完成后的行为

Supabase 配置完成后，公开文章会从 `posts` 表读取；管理员进入后台后可以创建、编辑、发布、归档和删除文章；访客留言与评论先进入 `pending` 状态，由管理员审核；图片上传到 `blog-media` Storage bucket；用户登录由 Supabase Auth 管理，管理员身份由 `profiles.role` 控制。

当前 GitHub Pages 版本仍然是静态展示版。要让这些接口真正在线，需要下一步把完整全栈项目部署到支持 Node.js 的平台，并在该平台填写三个 Supabase 变量。
